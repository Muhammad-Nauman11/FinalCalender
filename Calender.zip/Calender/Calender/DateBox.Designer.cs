﻿
namespace Calender
{
    partial class DateBox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblXMonth = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblXMonth
            // 
            this.lblXMonth.AutoSize = true;
            this.lblXMonth.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblXMonth.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblXMonth.Location = new System.Drawing.Point(14, 16);
            this.lblXMonth.Name = "lblXMonth";
            this.lblXMonth.Size = new System.Drawing.Size(30, 21);
            this.lblXMonth.TabIndex = 0;
            this.lblXMonth.Text = "00";
            this.lblXMonth.Click += new System.EventHandler(this.xMonth_Click);
            // 
            // DateBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.lblXMonth);
            this.Name = "DateBox";
            this.Size = new System.Drawing.Size(55, 47);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblXMonth;
    }
}
