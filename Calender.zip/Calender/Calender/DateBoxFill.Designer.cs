﻿
namespace Calender
{
    partial class DateBoxFill
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDateFill = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDateFill
            // 
            this.lblDateFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lblDateFill.FlatAppearance.BorderSize = 0;
            this.lblDateFill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblDateFill.Location = new System.Drawing.Point(0, 0);
            this.lblDateFill.Name = "lblDateFill";
            this.lblDateFill.Size = new System.Drawing.Size(55, 44);
            this.lblDateFill.TabIndex = 1;
            this.lblDateFill.Text = "b";
            this.lblDateFill.UseVisualStyleBackColor = false;
            this.lblDateFill.Click += new System.EventHandler(this.lblDateFill_Click);
            // 
            // DateBoxFill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.lblDateFill);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Name = "DateBoxFill";
            this.Size = new System.Drawing.Size(55, 47);
            this.Load += new System.EventHandler(this.DateBoxFill_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button lblDateFill;
    }
}
