﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calender
{
    public partial class EventSavingForm : Form
    {
        public EventSavingForm()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void EventSavingForm_Load(object sender, EventArgs e)
        {
            txtDate.Text = DateBoxFill.static_day + "/" + Form1.static_month + "/" + Form1.static_year;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            string descriptions = txtEvent.Text;
            if ( descriptions=="") {

                if ( Form1.eventsData[$"{Form1.static_month:00},{DateBoxFill.static_day:00}"] != "") {
                    Form1.deletDone = true;
                }
                Form1.eventsData.Remove($"{Form1.static_month:00},{DateBoxFill.static_day:00}");
            }
            else
            {
                Form1.eventsData[$"{Form1.static_month:00},{DateBoxFill.static_day:00}"] = $"{descriptions}";
                Form1.setEvent = true;
            }






            using (StreamWriter file = new StreamWriter(Form1.path))
                foreach (var entry in Form1.eventsData)
                    file.WriteLine("{0},{1}", entry.Key, entry.Value);
            this.Close();
        }

        private void txtEvent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
