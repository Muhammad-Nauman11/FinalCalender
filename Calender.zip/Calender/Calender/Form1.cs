﻿//Complete




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calender
{
    public partial class Form1 : Form
    {
        public static int static_year;
        public static int static_month;
        int month, year;
        public string eventDescriptions;
        public DateTime currentDate;
        public static bool setEvent=false;
        public static bool deletDone = false;

        public static Dictionary<string, string> eventsData = new Dictionary<string, string>();



        public static string path = "Events.txt";

        public Form1()
        {
            InitializeComponent();

            timer1.Start();
            DateTime currentDateTime = DateTime.Now;
            month = currentDateTime.Month;
            year = currentDateTime.Year;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            string date = dateTime.ToString("D");
            string AMP = dateTime.ToString("tt");
            this.lblTime.Text = dateTime.ToString("HH:mm:ss");
            this.lblDate.Text = date;
            this.lblAPM.Text=AMP;
            if (setEvent || deletDone) {
                datesTable.Controls.Clear();
                displayCalender();
                setEvent = false;
                deletDone = false;
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {


            if (File.Exists(path))
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }
            else {
                StreamWriter strm = File.CreateText(path);
                strm.Close();
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }

            displayCalender();

        }


        public void displayCalender() {
            string monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            static_year = year;
            static_month = month;

            DateTime StartsWithMonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            DateTime LastDayOfMonth = new DateTime(year, month, days);

            int previousMonth = month != 1 ? month - 1 : 12;

            int dayOfWeek = Convert.ToInt32(StartsWithMonth.DayOfWeek.ToString("d")) + 1;
            int lastDayOfWeek= Convert.ToInt32(LastDayOfMonth.DayOfWeek.ToString("d")) + 1;
            Console.WriteLine($"{lastDayOfWeek}") ;
            int previousMonthDays = DateTime.DaysInMonth(year,previousMonth);
            int X = 0;
            int Y = 0;
            int endDays = 1;

            lblMonYear.Text =monthName + " " + year;
            string descriptions = "";
            eventDescription.Clear();
            eventDescriptions = "";


            for (int dayNumber = 0; dayNumber <= days + dayOfWeek-2; dayNumber++)
            {
                X = dayNumber % 7 * 55;
                Y = dayNumber / 7 * 47;
                Console.WriteLine(days + lastDayOfWeek + dayOfWeek);

                if (dayNumber < dayOfWeek-2 || dayNumber - dayOfWeek + 2 == 0)
                {
                    DateBox dateBox = new DateBox();
                    dateBox.Location = new Point(X, Y);
                    int dateDay = previousMonthDays + dayNumber - dayOfWeek + 2;
                    dateBox.xDateDays(dateDay);
                    datesTable.Controls.Add(dateBox);
                }

                else
                {
                    DateBoxFill displayDate = new DateBoxFill();

                    foreach(string key in eventsData.Keys) {

                        if (key==$"{month:00},{dayNumber - dayOfWeek + 2:00}") {//00 will show number in two digits format
                        displayDate.changeColor();
                        descriptions = eventsData[key];
                        eventDescription.Text = eventDescription.Text +$"{monthName} {dayNumber - dayOfWeek + 2},{descriptions}\n" ;
                        }
                    }
                    displayDate.Location = new Point(X, Y);
                    displayDate.DateDays(dayNumber-dayOfWeek+2);
                    currentDate = new DateTime(year, month, dayNumber - dayOfWeek + 2);

                    if (currentDate.Date==DateTime.Now.Date) {
                        displayDate.MarkCurrentDate();
                    }
                    datesTable.Controls.Add(displayDate);
                }
            }

        }


        private void Previous_Click(object sender, EventArgs e)
        {
            month--;

            if (month <1)
            {
                month = 12;
                year--;
            }
            datesTable.Controls.Clear();
            displayCalender();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Next_Click(object sender, EventArgs e)
        {
            month++;
            if (month > 12){ 
                    month = 1;
                    year++;
            }
            datesTable.Controls.Clear();
            displayCalender();

        }
    }
}
