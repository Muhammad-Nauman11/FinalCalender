﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calender
{
    public partial class DateBoxFill : UserControl
    {
        public static string static_day;
        public DateBoxFill()
        {
            
            InitializeComponent();
        }

        private void DateBoxFill_Load(object sender, EventArgs e)
        {
            //this.BackColor = Color.Yellow;
        }
        private void DateBoxFill_MouseIn(object sender, EventArgs e)
        {
            //Panel pan = sender as Panel;
            this.BackColor = Color.Red;
        }
        public void DateDays(int numDay)
        {
            lblDateFill.Text = numDay+"";// Convert.ToString(numDay);
        }

        private void lblDateFill_Click(object sender, EventArgs e)
        {
            static_day = lblDateFill.Text;
            bool keyExist = false;

            EventSavingForm EventNow = new EventSavingForm();
            foreach (var item in Form1.eventsData)
            {
                if (item.Key== $"{Form1.static_month:00},{Convert.ToInt32(static_day):00}") {
                    keyExist = true;
                    Console.WriteLine($"{item.Key}_{item.Value}");
                    break;
                
                }
                
            }
            //Form1.eventsData.ContainsKey($"{Form1.static_month:00},{static_day:00}")
            if (keyExist)
            {
                EventNow.txtEvent.Text = Form1.eventsData[$"{Form1.static_month:00},{Convert.ToInt32(static_day):00}"];
                Console.WriteLine(Form1.eventsData[$"{Form1.static_month:00},{Convert.ToInt32(static_day):00}"]);

            }
            EventNow.ShowDialog();
            if (Form1.setEvent) {
                lblDateFill.BackColor = Color.FromArgb(255, 0, 0) ;
            }
            if (Form1.deletDone) {
                lblDateFill.BackColor =Color.FromArgb(40, 40, 40);
            }

            
        }
        public void changeColor() 
        {
            lblDateFill.BackColor= Color.FromArgb(255, 0, 0); 
        }
        public void MarkCurrentDate() {
            lblDateFill.FlatAppearance.BorderSize = 3;
            lblDateFill.FlatAppearance.BorderColor = Color.FromArgb(50,50,200);

        }
    }
}
