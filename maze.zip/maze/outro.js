const text = `THE WORLD IS NOW YOUR OYSTER. 
YOU LEARNED THE RULES AND PLAYED 
THE GAME WELL, YOU ARE NOW 
CLASSIFIED AS A FREE-MINDED 
CITIZEN. THOSE LEFT BEHIND MAY 
START TO VIEW YOU DIFFERENTLY 
AND VICE VERSA. BE PREPARED, 
STAY FOCUSED, AND KEEP YOUR 
FREQUENCY LEVEL HIGH.`;

let index = 0;
const speed = 50; // Typing speed in milliseconds
const animatedText = document.getElementById("animated-text");

function typeEffect() {
    if (index < text.length) {
        animatedText.innerHTML += text.charAt(index);
        index++;
        setTimeout(typeEffect, speed);
    }
}

window.onload = () => {
    typeEffect(); // Start typing effect
};
