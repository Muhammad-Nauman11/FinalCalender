document.addEventListener("DOMContentLoaded", function () {
    const text = "OUT OF TIME.";
    let index = 0;
    const speed = 100; // Typing speed in milliseconds
    const timeoutText = document.getElementById("timeout-text");

    function typeEffect() {
        if (index < text.length) {
            timeoutText.innerHTML += text.charAt(index);
            index++;
            setTimeout(typeEffect, speed);
        } else {
            timeoutText.style.borderRight = "none"; // Remove cursor effect after typing
        }
    }

    typeEffect(); // Start typing effect
});
