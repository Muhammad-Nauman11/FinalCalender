document.addEventListener("DOMContentLoaded", function () {
    // Simulated Game Data (Replace with dynamic data if needed)
    const gameItems = [
        { name: "coin", points: "20 PTS", icon: "coin.png" },
        { name: "diamond", points: "100 PTS", icon: "gem.png" },
        { name: "heart", points: "Extra 30 SEC", icon: "heart.png" }
    ];

    const gameIcons = [
        "siren.png",
        "powder.png",
        "skull.png",
        "injection.png"
    ];

    // Dynamically Load Items
    const itemsContainer = document.querySelector(".game-items");
    itemsContainer.innerHTML = ""; // Clear default HTML

    gameItems.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `<img src="${item.icon}" alt="${item.name}" class="icon"> = ${item.points}`;
        itemsContainer.appendChild(li);
    });

    // Load Game Icons
    const iconsContainer = document.querySelector(".game-icons");
    iconsContainer.innerHTML = "";

    gameIcons.forEach(iconSrc => {
        const img = document.createElement("img");
        img.src = iconSrc;
        img.classList.add("icon");
        iconsContainer.appendChild(img);
    });
});
