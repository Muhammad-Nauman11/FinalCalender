document.addEventListener("DOMContentLoaded", function () {
    const leaderboardBody = document.querySelector("#leaderboard tbody");

    // Fetch and parse CSV file
    fetch("scores.csv")
        .then(response => response.text())
        .then(data => {
            const rows = data.split("\n").slice(1).filter(row => row.trim() !== ""); // Remove header & empty rows
            const scores = rows.map(row => {
                const [user, email, score] = row.split(",");
                return {
                    user: user ? user.trim() : "Unknown",
                    email: email ? email.trim() : "N/A",
                    score: score ? parseInt(score.trim()) : 0
                };
            });

            // Sort scores from highest to lowest
            scores.sort((a, b) => b.score - a.score);

            // Populate leaderboard
            scores.forEach((entry, index) => {
                const tr = document.createElement("tr");
                tr.innerHTML = `<td>${index + 1}</td><td>${entry.user}</td><td>${entry.email}</td><td>${entry.score}</td>`;
                leaderboardBody.appendChild(tr);
            });
        })
        .catch(error => console.error("Error loading CSV:", error));

    // Download as Excel function
    document.getElementById("downloadExcel").addEventListener("click", function () {
        const table = document.getElementById("leaderboard");
        const ws = XLSX.utils.table_to_sheet(table);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "All Scores");

        // Download file
        XLSX.writeFile(wb, "Leaderboard.xlsx");
    });
});
