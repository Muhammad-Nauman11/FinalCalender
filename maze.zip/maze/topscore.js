document.addEventListener("DOMContentLoaded", function () {
    const leaderboard = document.getElementById("leaderboard");

    // Simulated API response or dynamic scores
    const topScores = [
        { name: "Player1", score: 2500 },
        { name: "Player2", score: 2300 },
        { name: "Player3", score: 2100 },
        { name: "Player4", score: 1900 },
        { name: "Player5", score: 1700 }
    ];

    // Dynamically create leaderboard items
    topScores.forEach((player, index) => {
        const li = document.createElement("li");
        li.innerHTML = `<span class="rank">${index + 1}.</span> <span class="score">${player.name} - ${player.score}</span>`;
        leaderboard.appendChild(li);

        // Delay each entry animation
        setTimeout(() => {
            li.classList.add("show");
        }, index * 1000); // 1-second delay for each score reveal
    });
});
